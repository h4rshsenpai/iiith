#include "prompt.h"
#include "headers.h"

int main()
{
    while (1)
    {
        prompt();
        char a[20];
        scanf("%s", a);
        // TAKE INPUT HERE
    }
}
