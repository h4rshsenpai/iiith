#include "prompt.h"
#include "headers.h"

void prompt() {
    printf("OS & NW TAs rock: ");    
}
